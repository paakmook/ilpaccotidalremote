import { Tracer } from "@luna/core";
import { MediaItem, PlayState, redux } from "@luna/lib";
import {
  sendWsMessage,
  startRemoteService,
  stopRemoteService,
} from "./remoteService.native";

const { trace } = Tracer("[DesktopConnect]");

export const unloads = new Set<() => void>();

interface IpcRendererLike {
  on: (channel: string, listener: (event: unknown, ...args: any[]) => void) => void;
  removeListener: (
    channel: string,
    listener: (event: unknown, ...args: any[]) => void
  ) => void;
}

function getIpcRenderer(): IpcRendererLike | undefined {
  const win = window as unknown as {
    __ipcRenderer?: IpcRendererLike;
    electron?: { ipcRenderer?: IpcRendererLike };
  };
  return win.__ipcRenderer ?? win.electron?.ipcRenderer;
}

type MobilePlayerState = "idle" | "paused" | "playing" | "buffering";

function mapTidalStateToMobile(rawState: string): MobilePlayerState {
  switch (rawState) {
    case "PLAYING":
      return "playing";
    case "NOT_PLAYING":
      return "paused";
    case "STALLED":
      return "buffering";
    case "IDLE":
    default:
      return "idle";
  }
}

let sessionActive = false;
let currentLoadedMediaId: string | null = null;
let currentLoadedDurationSec = 0;
let prefetchedMediaId: string | null = null;
let loadingGuardMediaId: string | null = null;
let lastProgressSentMs = 0;

const sessionCleanupFns = new Set<() => void>();

function clearSessionListeners(): void {
  for (const fn of sessionCleanupFns) {
    try {
      fn();
    } catch (err) {
      trace.err("Errore pulizia listener sessione:", err);
    }
  }
  sessionCleanupFns.clear();
}

function getCurrentDurationMs(): number {
  const psDuration =
    typeof PlayState.duration === "number" && Number.isFinite(PlayState.duration)
      ? PlayState.duration
      : 0;
  const effectiveSec = psDuration > 0 ? psDuration : currentLoadedDurationSec;
  return Math.max(0, Math.round(effectiveSec * 1000));
}

function getCurrentProgressMs(): number {
  const psTime =
    typeof PlayState.playTime === "number" && Number.isFinite(PlayState.playTime)
      ? PlayState.playTime
      : 0;
  const durationMs = getCurrentDurationMs();
  const rawMs = Math.max(0, Math.round(psTime * 1000));
  return durationMs > 0 ? Math.min(rawMs, durationMs) : rawMs;
}

async function sendStatusUpdate(state: MobilePlayerState): Promise<void> {
  await sendWsMessage({
    command: "onStatusUpdated",
    playerState: state,
    duration: getCurrentDurationMs(),
    progress: getCurrentProgressMs(),
    shuffle: Boolean(PlayState.shuffle),
    repeatMode: PlayState.repeatMode ?? 0,
    type: "media",
  });
}

function attachActiveSessionHooks(): void {
  clearSessionListeners();

  const unsubProgress = redux.intercept(
    "client.playback.playersignal",
    sessionCleanupFns,
    (payload: { time?: number }) => {
      if (!sessionActive) return;
      const now = Date.now();
      if (now - lastProgressSentMs < 250) return;
      lastProgressSentMs = now;

      const timeSec =
        typeof payload?.time === "number" && Number.isFinite(payload.time)
          ? payload.time
          : PlayState.playTime ?? 0;

      const durationMs = getCurrentDurationMs();
      const rawProgressMs = Math.max(0, Math.round(timeSec * 1000));
      const progressMs =
        durationMs > 0 ? Math.min(rawProgressMs, durationMs) : rawProgressMs;

      void sendWsMessage({
        command: "onProgressUpdated",
        duration: durationMs,
        progress: progressMs,
        type: "media",
      });
    }
  );
  sessionCleanupFns.add(unsubProgress);

  const unsubState = redux.intercept(
    "playbackControls/SET_PLAYBACK_STATE",
    sessionCleanupFns,
    (payload: string | { state?: string }) => {
      if (!sessionActive) return;
      const raw = typeof payload === "string" ? payload : payload?.state ?? "IDLE";
      const mapped = mapTidalStateToMobile(raw);
      void sendStatusUpdate(mapped);
    }
  );
  sessionCleanupFns.add(unsubState);

  const unsubEnded = redux.intercept(
    "playbackControls/ENDED",
    sessionCleanupFns,
    (payload: { reason?: string }) => {
      if (!sessionActive) return;
      if (payload?.reason === "completed") {
        const hasPrefetch = Boolean(prefetchedMediaId);
        void sendWsMessage({
          command: "onPlaybackCompleted",
          hasNextMedia: hasPrefetch,
          type: "media",
        });
        void sendWsMessage({
          command: "onRequestNextMedia",
          type: "media",
        });
      }
    }
  );
  sessionCleanupFns.add(unsubEnded);

  const unsubSkipNext = redux.intercept(
    "playbackControls/SKIP_NEXT",
    sessionCleanupFns,
    () => {
      if (!sessionActive) return;
      PlayState.pause();
      void sendWsMessage({
        command: "onStatusUpdated",
        playerState: "idle",
        type: "media",
      });
      void sendWsMessage({
        command: "onPlaybackCompleted",
        hasNextMedia: Boolean(prefetchedMediaId),
        type: "media",
      });
      void sendWsMessage({
        command: "onRequestNextMedia",
        type: "media",
      });
      return true;
    }
  );
  sessionCleanupFns.add(unsubSkipNext);

  void sendStatusUpdate(PlayState.playing ? "playing" : "paused");
}

function registerIpcChannel(
  ipc: IpcRendererLike,
  channel: string,
  handler: (event: unknown, ...args: any[]) => void
): void {
  ipc.on(channel, handler);
  unloads.add(() => {
    ipc.removeListener(channel, handler);
  });
}

async function initPlugin(): Promise<void> {
  const ipc = getIpcRenderer();
  if (!ipc) {
    trace.err("ipcRenderer non disponibile nel contesto window.");
    return;
  }

  registerIpcChannel(
    ipc,
    "remote.desktop.notify.session.state",
    (_event, state: number) => {
      if (state === 0) {
        sessionActive = false;
        currentLoadedMediaId = null;
        prefetchedMediaId = null;
        clearSessionListeners();
        trace.log("Sessione TIDAL Connect disconnessa.");
      } else if (!sessionActive) {
        sessionActive = true;
        attachActiveSessionHooks();
        trace.log("Sessione TIDAL Connect attiva (state:", state, ").");
      }
    }
  );

  registerIpcChannel(
    ipc,
    "remote.desktop.notify.media.changed",
    async (_event, payload: { mediaId?: string | number }) => {
      const rawId = payload?.mediaId;
      if (rawId === undefined || rawId === null) return;
      const mediaId = String(rawId);

      if (loadingGuardMediaId === mediaId) return;
      loadingGuardMediaId = mediaId;

      try {
        const item = await MediaItem.fromId(mediaId);
        if (!item) {
          trace.warn("MediaItem non trovato per ID:", mediaId);
          return;
        }

        currentLoadedMediaId = mediaId;
        currentLoadedDurationSec =
          typeof item.duration === "number" ? item.duration : 0;
        if (prefetchedMediaId === mediaId) {
          prefetchedMediaId = null;
        }

        await item.play();

        await sendWsMessage({
          command: "onRequestNextMedia",
          type: "media",
        });
      } catch (err) {
        trace.err("Errore riproduzione mediaId:", mediaId, err);
      } finally {
        loadingGuardMediaId = null;
      }
    }
  );

  registerIpcChannel(
    ipc,
    "remote.desktop.prefetch",
    (_event, payload: { mediaId?: string | number; mediaType?: number }) => {
      if (!payload?.mediaId) return;
      const itemId = String(payload.mediaId);
      prefetchedMediaId = itemId;

      const preloadAction = (redux.actions as Record<string, any>)[
        "player/PRELOAD_ITEM"
      ];
      if (typeof preloadAction === "function") {
        preloadAction({
          itemId,
          productType: payload.mediaType === 0 ? "track" : "video",
        });
      }
    }
  );

  registerIpcChannel(ipc, "remote.desktop.play", () => {
    PlayState.play();
  });

  registerIpcChannel(ipc, "remote.desktop.pause", () => {
    PlayState.pause();
  });

  registerIpcChannel(ipc, "remote.desktop.seek", (_event, timeMs: number) => {
    if (typeof timeMs === "number" && Number.isFinite(timeMs)) {
      PlayState.seek(Math.max(0, timeMs / 1000));
    }
  });

  registerIpcChannel(
    ipc,
    "remote.desktop.set.shuffle",
    (_event, shuffle: boolean) => {
      PlayState.setShuffle(Boolean(shuffle));
    }
  );

  registerIpcChannel(
    ipc,
    "remote.desktop.set.repeat.mode",
    (_event, mode: number) => {
      PlayState.setRepeatMode(mode as any);
    }
  );

  const handleVolumeMute = (
    _event: unknown,
    payload: { level?: number; mute?: boolean }
  ) => {
    if (!payload) return;
    const actions = redux.actions as Record<string, any>;

    if (
      typeof payload.mute === "boolean" &&
      typeof actions["playbackControls/SET_MUTE"] === "function"
    ) {
      actions["playbackControls/SET_MUTE"](payload.mute);
    }

    if (
      typeof payload.level === "number" &&
      Number.isFinite(payload.level) &&
      typeof actions["playbackControls/SET_VOLUME"] === "function"
    ) {
      const normalized =
        payload.level <= 1 ? payload.level * 100 : payload.level;
      const clamped = Math.max(0, Math.min(100, Math.round(normalized)));
      actions["playbackControls/SET_VOLUME"]({ volume: clamped });
    }
  };

  registerIpcChannel(ipc, "remote.destop.set.volume.mute", handleVolumeMute);
  registerIpcChannel(ipc, "remote.desktop.set.volume.mute", handleVolumeMute);

  unloads.add(() => {
    sessionActive = false;
    currentLoadedMediaId = null;
    prefetchedMediaId = null;
    clearSessionListeners();
    void stopRemoteService();
  });

  const result = await startRemoteService();
  if (result.ok) {
    trace.log(
      `Attivo come "${result.friendlyName}" (ID: ${result.deviceId}, IP: ${result.bindIp}, mDNS: ${result.mdnsBackend})`
    );
  } else {
    trace.err("Avvio servizio nativo fallito:", result.error);
  }
}

void initPlugin();
