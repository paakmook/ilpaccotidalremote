"use native";

import os from "os";
import path from "path";
import { createRequire } from "module";

const require = createRequire(import.meta.url);

interface RemoteDesktopControllerInstance {
  mdnsStartBroadcasting?: () => Promise<void> | void;
  mdnsStopBroadcasting?: () => Promise<void> | void;
  initialize: (originUrl: string) => Promise<void> | void;
  shutdown?: () => Promise<void> | void;
  remoteDesktopPlayer?: {
    remotePlayerProcess?: {
      stdout?: NodeJS.ReadableStream;
      stderr?: NodeJS.ReadableStream;
      kill?: () => void;
    };
  };
}

interface RemoteDesktopControllerModule {
  __running?: boolean;
  default?: new () => RemoteDesktopControllerInstance;
  RemoteDesktopController?: new () => RemoteDesktopControllerInstance;
}

interface BroadcastModule {
  generateDeviceId: () => string;
}

interface WebSocketModule {
  send: (payload: Record<string, unknown>) => void;
}

let activeResponder: any = null;
let activeService: any = null;
let activeController: RemoteDesktopControllerInstance | null = null;
let wsModule: WebSocketModule | null = null;
let rdcModuleRef: RemoteDesktopControllerModule | null = null;

function resolveTidalInternal<T>(relativeSubpath: string): T {
  const resPath = (process as any).resourcesPath || "";
  const candidates = [
    path.join(resPath, "original.asar", relativeSubpath),
    path.join(resPath, "app.asar", relativeSubpath),
    `./original.asar/${relativeSubpath}`,
    `./app.asar/${relativeSubpath}`,
  ];

  let lastErr: unknown;
  for (const candidate of candidates) {
    try {
      return require(candidate) as T;
    } catch (err) {
      lastErr = err;
    }
  }
  throw new Error(
    `[DesktopConnect:native] Impossibile caricare modulo interno TIDAL (${relativeSubpath}): ${String(lastErr)}`
  );
}

function loadCiaoModule(): any | null {
  const resPath = (process as any).resourcesPath || "";
  const candidates = [
    "@homebridge/ciao",
    path.join(resPath, "original.asar", "node_modules", "@homebridge", "ciao"),
    path.join(resPath, "app.asar", "node_modules", "@homebridge", "ciao"),
  ];
  for (const candidate of candidates) {
    try {
      const mod = require(candidate);
      return mod?.default ?? mod;
    } catch {
      // Prova il candidato successivo
    }
  }
  return null;
}

function getPrimaryLanIPv4(): string | undefined {
  const virtualPattern =
    /(vethernet|wsl|hyper-v|vmware|virtualbox|vbox|docker|tailscale|zerotier|wireguard|tun|tap|loopback)/i;
  const interfaces = os.networkInterfaces();

  let fallbackIp: string | undefined;

  for (const [name, addrs] of Object.entries(interfaces)) {
    if (!addrs) continue;
    for (const addr of addrs) {
      if (addr.family !== "IPv4" || addr.internal) continue;
      if (addr.address.startsWith("169.254.")) continue;

      if (!virtualPattern.test(name)) {
        return addr.address;
      }
      if (!fallbackIp) {
        fallbackIp = addr.address;
      }
    }
  }

  return fallbackIp;
}

export async function startRemoteService(customFriendlyName?: string): Promise<{
  ok: boolean;
  deviceId?: string;
  friendlyName?: string;
  bindIp?: string;
  mdnsBackend?: string;
  error?: string;
}> {
  try {
    if (activeResponder || activeService || rdcModuleRef?.__running) {
      await stopRemoteService();
    }

    const rdcMod = resolveTidalInternal<RemoteDesktopControllerModule>(
      "app/main/remoteDesktop/RemoteDesktopController.js"
    );
    const broadcastMod = resolveTidalInternal<BroadcastModule>(
      "app/main/mdns/broadcast.js"
    );
    const wsMod = resolveTidalInternal<WebSocketModule>(
      "app/main/remoteDesktop/websocket.js"
    );

    rdcModuleRef = rdcMod;
    wsModule = wsMod;

    if (rdcMod.__running) {
      return { ok: true, error: "Controller già in esecuzione" };
    }

    const ControllerCtor = rdcMod.default ?? rdcMod.RemoteDesktopController;
    if (!ControllerCtor) {
      throw new Error("Costruttore RemoteDesktopController non trovato in original.asar");
    }

    const deviceId = broadcastMod.generateDeviceId();
    const friendlyName =
      customFriendlyName?.trim() || `TidaLuna: ${os.hostname()}`;
    const bindIp = getPrimaryLanIPv4();

    const controller = new ControllerCtor();
    activeController = controller;
    rdcMod.__running = true;

    const ciao = loadCiaoModule();
    let mdnsBackend = "tidal-native";

    if (ciao && typeof ciao.getResponder === "function") {
      mdnsBackend = "@homebridge/ciao";
      const responder = ciao.getResponder(
        bindIp
          ? { interface: bindIp, disabledIpv6: true }
          : { disabledIpv6: true }
      );
      activeResponder = responder;

      const service = responder.createService({
        name: `RemoteDesktop-${deviceId}`,
        type: "tidalconnect",
        protocol: "tcp",
        port: 2019,
        txt: {
          mn: "RemoteDesktop",
          id: deviceId,
          fn: friendlyName,
          ca: "0",
          ve: "1",
        },
      });
      activeService = service;

      controller.mdnsStartBroadcasting = async () => {
        await service.advertise();
      };

      controller.mdnsStopBroadcasting = async () => {
        await service.end();
      };
    }

    await controller.initialize("https://desktop.tidal.com");

    const proc = controller.remoteDesktopPlayer?.remotePlayerProcess;
    if (proc?.stdout) {
      proc.stdout.on("data", (chunk: Buffer | string) => {
        const line = chunk.toString().trim();
        if (line) console.debug("[DesktopConnect:player]", line);
      });
    }
    if (proc?.stderr) {
      proc.stderr.on("data", (chunk: Buffer | string) => {
        const line = chunk.toString().trim();
        if (line) console.warn("[DesktopConnect:player:err]", line);
      });
    }

    return {
      ok: true,
      deviceId,
      friendlyName,
      bindIp: bindIp ?? "auto",
      mdnsBackend,
    };
  } catch (err) {
    console.error("[DesktopConnect:native] Errore avvio servizio:", err);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

export async function stopRemoteService(): Promise<void> {
  try {
    if (activeService) {
      await activeService.end().catch(() => {});
      activeService = null;
    }
    if (activeResponder) {
      await activeResponder.shutdown().catch(() => {});
      activeResponder = null;
    }
    if (activeController?.shutdown) {
      await activeController.shutdown().catch(() => {});
    }
    if (activeController?.remoteDesktopPlayer?.remotePlayerProcess?.kill) {
      try {
        activeController.remoteDesktopPlayer.remotePlayerProcess.kill();
      } catch {
        // Ignora errori se il processo è già terminato
      }
    }
  } finally {
    activeController = null;
    wsModule = null;
    if (rdcModuleRef) {
      rdcModuleRef.__running = false;
    }
  }
}

export async function sendWsMessage(
  payload: Record<string, unknown>
): Promise<boolean> {
  if (!wsModule || typeof wsModule.send !== "function") {
    return false;
  }
  try {
    wsModule.send(payload);
    return true;
  } catch (err) {
    console.error("[DesktopConnect:native] Errore invio WebSocket:", err);
    return false;
  }
}
